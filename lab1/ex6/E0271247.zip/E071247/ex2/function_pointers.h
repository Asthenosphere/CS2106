/*************************************
* Lab 1 Exercise 2
* Name: Wang Luo
* Student No: A0180092L
* Lab Group: 09
*************************************/

//declare your func_list array here
//remember to add in the keyword - extern

extern int (*func_list[5])( int );

void update_functions();
